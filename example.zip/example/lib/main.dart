import 'package:flutter/material.dart';
import 'package:animated_onboarding/animated_onboarding.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Onboard Screen',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Onboard Screen'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final _pages = [
    OnboardingPage(
        child:Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            new Center(
              child:
              Container(
                padding: EdgeInsets.all(5),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20.0),
                  child: Image.asset(
                    'assets/girl.png',
                    width: 100.0,
                    height: 100.0,
                    fit: BoxFit.fill,
                  ),
                ),
                //   new Image.asset(
                //   'assets/girl.png',
                //   width: 100.0,
                //   height: 100.0,
                //   fit: BoxFit.cover,
                // ),
              ),
            ),
            SizedBox(height: 50,),
            Container(
              padding: EdgeInsets.only(left:100,right: 100),
              child: Expanded(child: Text("Local News Stories",
                style: TextStyle(fontSize:30,fontWeight: FontWeight.bold,color: Colors.white,),
                textAlign: TextAlign.center,
              )),
            ),
          ],
        ),
        color: Color.fromARGB(253, 0, 64, 255)),
    OnboardingPage(
        child:Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            new Center(
              child:
              Container(
                padding: EdgeInsets.all(5),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20.0),
                  child: Image.asset(
                    'assets/girl.png',
                    width: 100.0,
                    height: 100.0,
                    fit: BoxFit.fill,
                  ),
                ),
                //   new Image.asset(
                //   'assets/girl.png',
                //   width: 100.0,
                //   height: 100.0,
                //   fit: BoxFit.cover,
                // ),
              ),
            ),
            SizedBox(height: 50,),
            Container(
              padding: EdgeInsets.only(left:100,right: 100),
              child: Expanded(child: Text("Choose your interests",
                style: TextStyle(fontSize:30,fontWeight: FontWeight.bold,color: Colors.white,),
                textAlign: TextAlign.center,
              )),
            ),
            // Expanded(child: Text("Choose your interests",style: TextStyle(fontSize:30,fontWeight: FontWeight.bold,color: Colors.white),))
          ],
        ),
        color: Color.fromARGB(253, 255, 204, 204)),
    OnboardingPage(
        child:Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            new Center(
              child:
              Container(
              decoration: new BoxDecoration(
                color: Color.fromARGB(253, 255, 204, 204),
                borderRadius: BorderRadius.circular(20.0),
              ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20.0),
                  child: Image.asset(
                    'assets/girl.png',
                    width: 100.0,
                    height: 100.0,
                    fit: BoxFit.fill,
                  ),
                ),
                //   new Image.asset(
                //   'assets/girl.png',
                //   width: 100.0,
                //   height: 100.0,
                //   fit: BoxFit.cover,
                // ),
              ),
            ),
            SizedBox(height: 50,),
            Container(
              padding: EdgeInsets.only(left:100,right: 100),
              child: Expanded(child: Text("Drag and drop to move",
                style: TextStyle(fontSize:30,fontWeight: FontWeight.bold,color: Colors.black,),
                textAlign: TextAlign.center,
              )),
            ),
            // Container(
            //   padding: EdgeInsets.only(left: 20,right: 20),
            //   child:Expanded(child: Text("Drag and drop to move",style: TextStyle(fontSize:30,fontWeight: FontWeight.bold,color: Colors.black),))
            // )
          ],
        ),
        color: Colors.white),

  ];
  @override
  Widget build(BuildContext context)
  {
    return AnimatedOnboarding(
      pages: _pages,
      pageController: PageController(),
      onFinishedButtonTap: () {
        print("FINISHED!!");
      },
      topLeftChild: Text(
        "Storief",
        style: TextStyle(color: Colors.white, fontSize: 24),
      ),
      topRightChild: FlatButton(
        child: Text(
          "Skip",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        onPressed: () {},
      ),
    );
  }
}
